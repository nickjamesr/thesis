#include "heads/libqp.h"

using namespace std;

hermitian::hermitian(){
  // Default (empty) constructor
  size = 0;
}

hermitian::hermitian(uint N){
  // Identity constructor. Returns the NxN identity matrix
  size = N;
  data = new double[2*N*N];
  identity();
}

hermitian::hermitian(const hermitian& H){
  // Copy constructor
  size = H.size;
  data = new double[2*size*size];
  memcpy(data, H.data, 2*size*size*sizeof(double));
}

hermitian::~hermitian(){
  // Destructor: ensures that the gsl matrix meory is freed
  if (size)
    delete[] data;
}

void hermitian::identity(){
  // Initialise elements to the identity
  uint idx, jdx;

  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);   // Index of real part
      jdx = idx + 1;          // Index of imaginary part
      if (i==j)
        data[idx] = 1;
      else
        data[idx] = 0;
      data[jdx] = 0;
    }
  }
}

void hermitian::gaussian(ulong seed){
  gsl_rng *r=gsl_rng_alloc(gsl_rng_ranlxd1);
  double x, y;
  uint idx, jdx;

  gsl_rng_set(r, seed);
  
  for (uint i=0; i<size; i++){
    // Diagonal
    idx = 2*i*(size + 1);
    jdx = idx+1;
    x = gsl_ran_gaussian(r, 1.0);
    data[idx] = x;
    data[jdx] = 0;
    for (uint j=(i+1); j<size; j++){
      x = gsl_ran_gaussian(r, 1.0);
      y = gsl_ran_gaussian(r, 1.0);
      // Upper triangle
      idx = 2*(i*size + j);
      jdx = idx + 1;
      data[idx] = x;
      data[jdx] = y;
      // Lower triangle
      idx = 2*(j*size + i);
      jdx = idx + 1;
      data[idx] = x;
      data[jdx] = -y;
    }
  }

  gsl_rng_free(r);
}

void hermitian::read(const string fname){
  ifstream fin;
  double x, y;
  uint idx, jdx;
  char c;

  fin.open(fname.data());

  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      fin >> skipws >> x >> noskipws >> c;
      if (c == '+'){
        // Full complex number: get imaginary part
        fin >> y >> c;
      }
      else if (c == '-'){
        fin >> y >> c;
        y *= -1;
      }
      else if (c == 'j'){
        // Pure imaginary number
        y = x;
        x = 0;
      }
      else if (c == ' ' or c == '\n'){
        // Pure real number
        y = 0;
      }
      else{
        cout << "Format Error\nCorrect format x+yj" << endl;
        exit(1);
      }
      idx = 2*(j + i*size);
      jdx = idx + 1;
      data[idx] = x;
      data[jdx] = y;
    }
  }

  fin.close();
}

hermitian hermitian::operator=(const hermitian& H){
  // Copy constructor
  if (size)
    delete[] data;

  size = H.size;
  data = new double[2*size*size];
  memcpy(data, H.data, 2*size*size*sizeof(double));

  return *this;
}

hermitian hermitian::operator*(const double& z){
  hermitian H(size);
  
  for (uint i=0; i<(2*size*size); i++)
    H.data[i]=this->data[i]*z;

  return H;
}

hermitian hermitian::operator+(const hermitian& that){
  // Addition of two Hermitian matrices
  if (size != that.size)
    cout << "Incompatible sizes for hermitian addition" << endl;

  hermitian H(size);
  for (uint i=0; i<(2*size*size); i++){
    H.data[i] = this->data[i] + that.data[i];
  }

  return H;
}

uint hermitian::get_size() const{
  return size;
}

double* hermitian::matrix() const{
  return data;
}

void hermitian::print(ostream &fout) const{
  // Prints a representation of the matrix to stdout
  double x, y;
  uint idx, jdx;

  fout << "[ ";
  for (uint i=0; i<size; i++){
    fout << "[ ";
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      x = data[idx];
      y = data[jdx];
      fout << CPRINT(x,y) << " ";
    }
    if (i == size-1)
      fout << "] ";
    else
      fout << "]\n  ";
  }
  fout << "]" << endl;
}

void hermitian::write(const string fname) const{
  // Writes a representation of the matrix to the file "fname"
  ofstream fout;
  double x, y;
  uint idx, jdx;

  fout.open(fname.data());
  fout << showpos;

  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      x = data[idx];
      y = data[jdx];
      fout << x << y << "j ";
    }
    fout << endl;
  }

  fout.close();
}

