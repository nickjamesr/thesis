#include "heads/libqp.h"

void qp::orthogonalise(gsl_matrix_complex* m){
  // row-wise orthogonalisation of a GSL complex matrix
  uint rows=m->size1;         // number of rows
  uint cols=m->size2;         // number of columns
  gsl_vector_complex_view u, v;
  gsl_complex uv;
  double uu;

  if (rows>cols){
    cout << "Overconstrained: cannot orthogonalise row-wise" << endl;
    exit(1);
  }

  for (uint i=0; i<rows; i++){
    u = gsl_matrix_complex_row(m, i);
    for (uint j=0; j<i; j++){
      v = gsl_matrix_complex_row(m, j);
      // Subtract component of u parallel to v: u = (-uv/vv)v + u
      gsl_blas_zdotc(&v.vector, &u.vector, &uv);
      gsl_blas_zaxpy(gsl_complex_negative(uv), &v.vector, &u.vector);
    }
    // Normalise u: u = (1/uu)u
    uu = gsl_blas_dznrm2(&u.vector);
    gsl_blas_zdscal(1/uu, &u.vector);
  }
}

void qp::printmatrix(uint size, double* data){
  // Prints a representation of the matrix to stdout
  double x,y;
  uint idx, jdx;

  cout << "[ ";
  for (uint i=0; i<size; i++){
    cout << "[ ";
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      x = data[idx];
      y = data[jdx];
      cout << CPRINT(x,y) << " ";
    }
    if (i == size-1)
      cout << "] ";
    else
      cout << "]\n  ";
  }
  cout << "]" << endl;
}

complex<double> qp::cpermanent(uint size, double* data){
  // agrees with naive algorithm
  gsl_complex prod, sum, aij, perm=gsl_complex_rect(0,0);
  gsl_combination *subset;
  int sign=1;
  uint jj, idx, jdx;

  for (uint k=1; k<=size; k++){
    subset = gsl_combination_calloc(size, k);
    sign *= -1;

    do{
      // For each subset of {1,2,...,size} with k elements
      prod = gsl_complex_rect(1, 0);

      for (uint i=0; i<size; i++){
        // Evaluate product over row sums
        sum = gsl_complex_rect(0, 0);

        for (uint j=0; j<k; j++){
          // Evaluate sum over row
          jj = gsl_combination_get(subset, j);
          idx = 2*(i*size + jj);
          jdx = idx + 1;
          aij = gsl_complex_rect(data[idx], data[jdx]);
          sum = gsl_complex_add(sum, aij);
        }

        prod = gsl_complex_mul(prod, sum);
      }

      prod = gsl_complex_mul_real(prod, sign);
      perm = gsl_complex_add(perm, prod);
    } while (gsl_combination_next(subset) == GSL_SUCCESS);

    gsl_combination_free(subset);
  }

  sign = pow(-1, size);
  perm = gsl_complex_mul_real(perm, sign);

  return complex<double>(GSL_REAL(perm), GSL_IMAG(perm));
}

double qp::permanent(uint size, double* data){
// TODO: efficient approximation algorithm for real positive-definite
// matrices
  double prod, sum, aij, perm=0.0;
  gsl_combination *subset;
  int sign=1;
  uint jj, idx;

  for (uint k=1; k<=size; k++){
    subset = gsl_combination_calloc(size, k);
    sign *= -1;

    do{
      // For each subset of {1,2,...,size} with k elements
      prod = 1.0;

      for (uint i=0; i<size; i++){
        // Evaluate product over row sums
        sum = 0.0;

        for (uint j=0; j<k; j++){
          // Evaluate sum over row
          jj = gsl_combination_get(subset, j);
          idx = i*size + jj;
          aij = data[idx];
          sum += aij;
        }

        prod *= sum;
      }

      prod *= sign;
      perm += prod;
    } while (gsl_combination_next(subset) == GSL_SUCCESS);

    gsl_combination_free(subset);
  }

  sign = pow(-1, size);
  perm *= sign;

  return perm;
}

unitary qp::expi(hermitian H, double t){
  uint idx, jdx, size=H.get_size();
  gsl_matrix_complex* m, *rtn, *evec, *expdiag;
  gsl_vector* eval;
  gsl_vector_complex* cdiag;
  gsl_eigen_hermv_workspace* wspace;
  gsl_vector_complex_view diag;
  unitary U(size);
  gsl_complex z;
  double* data=H.matrix();
  double lambda;

  // Construct a GSL matrix from the Hermitian H
  m = gsl_matrix_complex_alloc(size, size);
  
  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      gsl_matrix_complex_set(m, i, j, gsl_complex_rect(data[idx], data[jdx]));
    }
  }

  // Do the diagonalisation
  wspace = gsl_eigen_hermv_alloc(size);
  evec = gsl_matrix_complex_alloc(size, size);
  expdiag = gsl_matrix_complex_calloc(size, size);
  rtn = gsl_matrix_complex_calloc(size, size);
  eval = gsl_vector_alloc(size);
  cdiag = gsl_vector_complex_alloc(size);

  gsl_eigen_hermv(m, eval, evec, wspace);

  // Construct the unitary
  gsl_matrix_complex_set_zero(m);
  // Exponentiate the diagonal matrix
  for (uint i=0; i<size; i++){
    lambda = gsl_vector_get(eval, i);
    z = gsl_complex_mul_real(gsl_complex_rect(0,1), t*lambda);
    z = gsl_complex_exp(z);
    gsl_vector_complex_set(cdiag, i, z);
  }
  diag = gsl_matrix_complex_diagonal(expdiag);
  gsl_vector_complex_memcpy(&diag.vector, cdiag);

  // Multiply the matrices to obtain a unitary
  gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, gsl_complex_rect(1,0), evec,
    expdiag, gsl_complex_rect(1,0), rtn);
  gsl_blas_zgemm(CblasNoTrans, CblasConjTrans, gsl_complex_rect(1,0), rtn,
    evec, gsl_complex_rect(1,0), m);

  // Copy the matrices back to the unitary
  data = U.matrix();
  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      z = gsl_matrix_complex_get(m, i, j);
      data[idx] = GSL_REAL(z);
      data[jdx] = GSL_IMAG(z);
    }
  }

  gsl_matrix_complex_free(m);
  gsl_matrix_complex_free(evec);
  gsl_matrix_complex_free(expdiag);
  gsl_matrix_complex_free(rtn);
  gsl_eigen_hermv_free(wspace);
  gsl_vector_complex_free(cdiag);
  gsl_vector_free(eval);

  return U;
}

/*hermitian qp::logi(unitary U, double t){
  uint idx, jdx, size=U.get_size();
  gsl_matrix_complex* m, *rtn, *evec, *argdiag, *id;
  gsl_vector_complex* eval;
  gsl_eigen_gen_workspace *wspace = gsl_eigen_gen_alloc(size);

  gsl_eigen_gen_free(wspace);
}*/

double qp::rng_poly(uint n, gsl_rng *r){
  double uniform, poly;
  uniform = gsl_rng_uniform(r);
  if (n == 1)
    return uniform;
  poly = 1.0 - pow(uniform,1.0/((double) n-1.0));
  return poly;
}

hermitian qp::walk(uint nmodes){
  hermitian H(nmodes);
  double offdiag[20]={0.466,0.540,0.504,0.515,0.494,0.451,0.508,0.511,0.483,
    0.505,0.547,0.471,0.493,0.499,0.447,0.467,0.544,0.524,0.510,0.503};
  H.identity();
  for (uint i=0; i<nmodes; i++){
    H.matrix()[2*(i*nmodes+i)]=2.122;
  }
  for (uint i=0; i<nmodes-1; i++){
    H.matrix()[2*(i*nmodes+i+1)]=offdiag[i];
    H.matrix()[2*((i+1)*nmodes+i)]=offdiag[i];
  }
  return H;
}


