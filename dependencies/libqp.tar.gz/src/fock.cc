#include "heads/libqp.h"

using namespace std;

fock::fock(){
  // Default (empty) constructor
  m = 1;
  p = 1;
  state = new uint[1];
  state[0] = 0;
}

fock::fock(uint modes, uint photons){
  // Constructor to initialise with a number of modes, m and a number of
  // photons, p. Default state is one photon in each of the first p modes
  m = modes;
  p = photons;
  state = new uint[p];
  if (p<=m){
    for (uint i=0; i<p; i++){
      state[i] = i;
    }
  }
  else{
    for (uint i=0; i<p; i++){
      state[i] = 0;
    }
  }
}

fock::fock(uint modes, uint photons, uint *data){
  // Constructor to initialise with a specific state. Tests that the state is
  // valid
  m = modes;
  p = photons;
  state = new uint[p];
  for (uint i=0; i<photons; i++){
    if (data[i] >= m){
      cerr << "Invalid mode" << state[i] << " for " << m << " mode Fock state"
        << endl;
      exit(1);
    }
  }
  memcpy(state, data, p*sizeof(uint));
}

fock::fock(const fock& f){
  // Copy constructor
  m = f.m;
  p = f.p;
  state = new uint[p];
  memcpy(state, f.state, p*sizeof(uint));
}

fock::~fock(){
  // Destructor: frees the memory used by the multiset containing the state
  delete[] state;
}

void fock::random(ulong s){
  // Initialize to a random state
  gsl_rng *r=gsl_rng_alloc(gsl_rng_ranlxd1);
  double x, frac;
  ulong pp=p, mm=m;

  gsl_rng_set(r, s);

  while (pp>0 && mm>0){
    x = gsl_rng_uniform(r);
    frac = ((double) pp)/((double) (pp+mm-1));
    if (x < frac){
      // Place a photon in mode m
      state[pp-1] = mm-1;
      pp--;
    }
    else{
      // Reduce available modes by one
      mm--;
    }
  }

  for (uint i=1; i<pp; i++){
    // Any remaining photons must go in mode 0
    state[i-1] = 0;
  }

}

void fock::random_noreps(ulong s){
  // Initialize to a random state
  gsl_rng *r=gsl_rng_alloc(gsl_rng_ranlxd1);
  double x, frac;
  ulong pp=p, mm=m;

  gsl_rng_set(r, s);

  while (pp>0 && mm>0){
    x = gsl_rng_uniform(r);
    frac = ((double) pp)/((double) (pp+mm-1));
    if (x < frac){
      // Place a photon in mode m
      state[pp-1] = mm-1;
      pp--;
    }
    else{
      // Reduce available modes by one
      mm--;
    }
  }

  for (uint i=1; i<pp; i++){
    // Any remaining photons must go in mode 0
    state[i-1] = 0;
  }

}

fock& fock::operator=(const fock& f){
  // Assignment operator
  delete[] state;
  m = f.m;
  p = f.p;
  state = new uint[p];
  memcpy(state, f.state, p*sizeof(uint));
  return *this;
}

uint fock::n_photons() const{
  // Returns number of photons in the state
  return p;
}

uint fock::n_modes() const{
  // Returns number of modes in the state
  return m;
}

uint fock::photon(uint n) const{
  // Returns the index of the mode occupied by the n-th photon
  if (n>=p){
    cerr << "Photon index out of range" << endl;
    exit(1);
  }
  return state[n];
}

int fock::prev(){
  // Cycle through states in reverse lexicographic order
  for (uint i=p-1; i>=1; i--){
    if (state[i-1]!=state[i]){
      state[i]--;
      for (uint j=(i+1); j<p; j++){
        state[j] = (m-1);
      }
      return 1;
    }
  }
  if (state[0]!=0){
    state[0]--;
    for (uint j=1; j<p; j++){
      state[j] = (m-1);
    }
    return 1;
  }
  return 0;
}

int fock::prev_noreps(){
  // Cycle through states in reverse lexicographic order without permitting
  // multiple photons in a single mode
  // First check for duplicates
  uint temp=state[0];
  for (uint i=1; i<p; i++){
    if (state[i]==temp){
      cerr << "Invalid noreps state"; this->print(cerr);
      return 0;
    }
    temp = state[i];
  }
  for (uint i=0; i<p; i++){
    if (state[i] > m-1){
      cerr << "Invalid state: "; this->print(cerr);
      return 0;
    }
  }
  for (uint i=p-1; i>=1; i--){
    if (state[i-1]!=state[i]-1){
      state[i]--;
      for (uint j=(i+1); j<p; j++){
        state[j] = (m-p+j);
      }
      return 1;
    }
  }
  if (state[0]!=0){
    state[0]--;
    for (uint j=1; j<p; j++){
      state[j] = (m-p+j);
    }
    return 1;
  }
  return 0;
}

int fock::next(){
  // Cycle through states in forward lexicographic order
  for (uint i=p; i>0; i--){
    if (state[i-1]!=m-1){
      state[i-1]++;
      for (uint j=i; j<p; j++){
        state[j]=state[i-1];
      }
      return 1;
    }
  }
  return 0;
}

int fock::next_noreps(){
  // Cycle through states in forward lexicographic order without permitting
  // multiple photons in a single mode
  // First check for duplicates
  uint temp=state[0];
  for (uint i=1; i<p; i++){
    if (state[i]==temp){
      cerr << "Invalid noreps state: ";
      this->print(cerr);
      return 0;
    }
    temp = state[i];
  }
  for (uint i=0; i<p; i++){
    if (state[i] > m-1){
      cerr << "Invalid state: "; this->print(cerr);
      return 0;
    }
  }
  for (uint i=p; i>0; i--){
    if (state[i-1]!=m-p+i-1){
      state[i-1]++;
      for (uint j=i; j<p; j++){
        state[j]=state[i-1]+j-i+1;
      }
      return 1;
    }
  }
  return 0;
}

void fock::print(ostream &fout) const{
  // Prints a representation of the state to stdout
  fout << "{";
  for (uint i=0; i<p; i++){
    fout << " " << state[i];
  }
  fout << " }" << endl;
}

bool fock::contains(uint n, bool atleast) const{
  uint count=0;
  if (n >= m){
    return false;
  }
  else{
    for (uint i=0; i<p; i++){
      if (state[i]==n){
        count++;
      }
    }
    if (count==0){
      return false;
    }
    else if (count==1){
      return true;
    }
    else if (atleast){
      return true;
    }
    else{
      return false;
    }
  }
}






