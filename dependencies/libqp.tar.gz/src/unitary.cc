#include "heads/libqp.h"

using namespace std;


// Private methods

void unitary::zero(){
  // Sets all elements to zero. Does not preserve unitarity, so private method
  uint N=2*size*size;
  for (uint i=0; i<N; i++){
    data[i] = 0;
  }
}

unitary::unitary(){
  // Default (empty) constructor
  size = 0;
}

unitary::unitary(uint N){
  // Identity constructor. Returns the NxN identity matrix
  size = N;
  data = new double[2*N*N];
  identity();
}

unitary::unitary(const unitary& U){
  // Copy constructor
  size = U.size;
  data = new double[2*size*size];
  memcpy(data, U.data, 2*size*size*sizeof(double));
}

unitary::unitary(const reck& R){
  // Convert a Reck scheme to a unitary
  // TODO: could optimise the multiplications: currently just goes down the
  // whole column, but it's actually not full
  size = R.get_size();
  double r, phi, cosp, sinp, cosw, sinw, alpha, real, imag, kpr, kpi, kqr, kqi;
  uint kp, kq, p, q, idx;

  data = new double[2*size*size];

  identity();
  
  for (uint i=0; i<(size-1); i++){
    for (uint j=(i+1); j<size; j++){
      // Post-multiply by u_{ij}
      q = size-j+i;
      p = q-1;
      r = R.get_r(i,j);
      phi = R.get_phi(i,j);
      cosw = sqrt(r);     // cos(omega) = sqrt(r)
      sinw = sqrt(1-r);   // sin(omega) = sqrt(1-r)
      cosp = cos(phi);
      sinp = sin(phi);
      // Now mix p-th and q-th columns
      for (uint k=0; k<size; k++){
        // update the k-th element in the p-th and q-th column
        // Indices for real and imaginary parts
        kp = 2*(k*size + p);
        kq = 2*(k*size + q);
        kpr = data[kp];
        kpi = data[kp+1];
        kqr = data[kq];
        kqi = data[kq+1];
        data[kp] = kpr*cosw*cosp - kpi*cosw*sinp + kqr*sinw;
        data[kp+1] = kpi*cosw*cosp + kpr*cosw*sinp + kqi*sinw;
        data[kq] = kpr*sinw*cosp - kpi*sinw*sinp - kqr*cosw;
        data[kq+1] = kpi*sinw*cosp + kpr*sinw*sinp - kqi*cosw;
      }
    }
  }
  // Post multiply by phases - diagonal matrix alpha
  for (uint i=0; i<size; i++){
    // Multiply i-th column by the i-th phase
    alpha = R.get_alpha(i);
    cosw = cos(alpha);
    sinw = sin(alpha);
    for (uint j=0; j<size; j++){
      idx = 2*(j*size + i);
      real = data[idx];
      imag = data[idx+1];
      data[idx] = real*cosw - imag*sinw;
      data[idx+1] = imag*cosw + real*sinw;
    }
  }
}

unitary::~unitary(){
  // Destructor: ensures that the matrix memory is freed
  if (size)
    delete[] data;
}

void unitary::identity(){
  // Initialise elements to the identity
  uint idx, jdx;

  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);   // Index of real part
      jdx = idx + 1;          // Index of imaginary part
      if (i==j)
        data[idx] = 1;
      else
        data[idx] = 0;
      data[jdx] = 0;
    }
  }
}

void unitary::haar(ulong s){
  // Initialise elements to a Haar-random unitary
  // Uses the Gaussian-orthogonalisation method
  gsl_matrix_complex *m;
  gsl_complex z;
  gsl_rng *r = gsl_rng_alloc(gsl_rng_ranlxd1);
  double x,y;
  uint idx, jdx;

  gsl_rng_set(r, s);

  // Create a random Gaussian matrix (not unitary)
  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      x = gsl_ran_gaussian(r, 1.0);
      y = gsl_ran_gaussian(r, 1.0);
      data[idx] = x;
      data[jdx] = y;
    }
  }

  gsl_rng_free(r);

  // Initialise the GSL complex matrix
  m = gsl_matrix_complex_alloc(size, size);

  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      gsl_matrix_complex_set(m, i, j, gsl_complex_rect(data[idx], data[jdx]));
    }
  }

  // Orthogonalise the matrix
  qp::orthogonalise(m);

  // Copy the data back
  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      z = gsl_matrix_complex_get(m, i, j);
      data[idx] = GSL_REAL(z);
      data[jdx] = GSL_IMAG(z);
    }
  }

  // Free memory in GSL complex matrix
  gsl_matrix_complex_free(m);
}

void unitary::read(const string fname){
  ifstream fin;
  double x, y;
  uint idx, jdx;
  char c;

  fin.open(fname.data());

  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      fin >> skipws >> x >> noskipws >> c;
      if (c == '+'){
        // Full complex number: get imaginary part
        fin >> y >> c;
      }
      else if (c == '-'){
        fin >> y >> c;
        y *= -1;
      }
      else if (c == 'j'){
        // Pure imaginary number
        y = x;
        x = 0;
      }
      else if (c == ' ' or c == '\n'){
        // Pure real number
        y = 0;
      }
      else{
        cout << "Format Error\nCorrect format x+yj" << endl;
        exit(1);
      }
      idx = 2*(j + i*size);
      jdx = idx + 1;
      data[idx] = x;
      data[jdx] = y;
    }
  }

  fin.close();
}

unitary unitary::operator=(const unitary& U){
  // Assignment operator
  if (size)
    delete[] data;

  size = U.size;
  data = new double[2*size*size];
  memcpy(data, U.data, 2*size*size*sizeof(double));

  return *this;
}

unitary unitary::operator*(const unitary& U) const{
  // unitary-unitary multiplication
  if (size != U.size){
    cerr << "Incompatible dimension in U*U multiplication" << endl;
    exit(1);
  }
  cerr << "Unitary matrix multiplication not yet implemented" << endl <<
      "Returning identity" << endl;
  unitary V(size);
  return V;
}

complex<double> unitary::amplitude(const fock& out, const fock& in,
    bool quantum) const{
  double *trans;
  complex<double> amp;
  double norm=1;
  uint count=1, curr=0;
  uint p, ii, jj, idx, jdx, iidx, jjdx;

  // Check whether mode numbers match
  if (out.n_modes() != in.n_modes() || out.n_modes() != size ||
      in.n_modes() != size){
    cerr << "Incompatible mode number for amplitude" << endl;
    exit(1);
  }

  // Check whether photon numbers match
  if (out.n_photons() != in.n_photons()){
    cerr << "Incompatible photon number for amplitude" << endl;
    exit(1);
  }

  p = out.n_photons();

  // Calculate the normalisation constant
  // *** Chance of overflow here *** //
  if (in.n_photons() > 1){
    curr = in.photon(0);
    for (uint i=1; i<p; i++){
      if (in.photon(i) == curr){
        count += 1;
        norm *= count;
      }
      else{
        curr = in.photon(i);
        count = 1;
      }
    }
    curr = out.photon(0);
    count = 1;
    for (uint i=1; i<p; i++){
      if (out.photon(i) == curr){
        count += 1;
        norm *= count;
      }
      else{
        curr = out.photon(i);
        count = 1;
      }
    }
  }

  p = out.n_photons();            // number of photons

  if (quantum){
    norm = sqrt(norm);
    trans = new double[2*p*p];      // Allocate transition matrix
    // Construct the transition matrix
    for (uint i=0; i<p; i++){
      for (uint j=0; j<p; j++){
        ii = out.photon(i);
        jj = in.photon(j);
        idx = 2*(i*p + j);        // (real) Index into transition matrix
        jdx = idx + 1;            // (imag)
        iidx = 2*(ii*size + jj);  // (real) Index into U
        jjdx = iidx + 1;          // (imag)
        trans[idx] = data[iidx];
        trans[jdx] = data[jjdx];
      }
    }
    // Get the permanent of the transition matrix
    amp = qp::cpermanent(p, trans);
  }
  else{
    trans = new double[p*p];
    for (uint i=0; i<p; i++){
      for (uint j=0; j<p; j++){
        ii = out.photon(i);
        jj = in.photon(j);
        idx = i*p + j;            // (real) Index into transition matrix
        iidx = 2*(ii*size + jj);  // (real) Index into U
        jjdx = iidx + 1;          // (imag)
        trans[idx] = (data[iidx]*data[iidx] + data[jjdx]*data[jjdx]);
      }
    }
    // Get the permanent of the transition matrix
    amp = qp::permanent(p, trans);
  }

  delete[] trans;

  return amp/norm;
}

bool unitary::test(){
  // Tests unitarity of matrix 
  complex<double> uk, vk, dot, res;
  uint ir, ii, jr, ji;
  double ur, ui, vr, vi;

  for (uint i=0; i<size; i++){
    // Vector u = i-th row
    for (uint j=i; j<size; j++){
      dot = complex<double>(0,0);
      // Vector v = j-th row
      // Take dot product
      for (uint k=0; k<size; k++){
        ir = 2*(i*size + k);
        ii = ir + 1;
        jr = 2*(j*size + k);
        ji = jr + 1;
        ur = data[ir];
        ui = data[ii];
        vr = data[jr];
        vi = data[ji];
        uk = complex<double>(ur, ui);
        vk = complex<double>(vr, -vi);
        dot += (uk*vk);
      }
      if (i==j)
        res += (dot-complex<double>(1,0));
      else
        res += dot;
    }
  }
  return (abs(res) <= size*size*DBL_EPSILON);
}

complex<double> unitary::permanent(){
  // Returns the permanent of the matrix. Used in testing/debugging
  complex<double> r;
  clock_t start, finish;

  start = clock();
  r = qp::permanent(size, data);
  finish = clock();
  cout << (double) (finish-start)/(double) CLOCKS_PER_SEC << endl;
  cout << "Ryser: " << r << endl;

  return r;
}

fock unitary::sample(const fock& in){
  // Given an input state, return a sample from the output distribution
  // TODO
  fock out;
  uint modes=in.n_modes(), photons=in.n_photons();
  if (modes != size){
    cerr << "Incompatible number of modes for sampling" << endl;
    exit(1);
  }
  out = fock(modes, photons);

  return out;
}

uint unitary::get_size() const{
  return size;
}

double* unitary::matrix() const{
  return data;
}

void unitary::clean(){
  for (uint i=0; i<2*size*size; i++){
    if (fabs(data[i]) < 1.0e-12){
      data[i] = 0.0;
    }
  }
}

void unitary::realborder(void){
  double x,y,r,s,c;
  // Rows
  for (uint i=0; i<size; i++){
    x = data[2*size*i];
    y = data[2*size*i+1];
    r = sqrt(x*x + y*y);
    c = (r==0)?(1.0):(x/r);
    s = (r==0)?(0.0):(y/r);
    for (uint j=0; j<size; j++){
      x = data[2*(size*i+j)];
      y = data[2*(size*i+j)+1];
      data[2*(size*i+j)] = x*c + y*s;
      data[2*(size*i+j)+1] = y*c - x*s;
    }
  }
  // Columns
  for (uint j=1; j<size; j++){
    x = data[2*j];
    y = data[2*j+1];
    r = sqrt(x*x + y*y);
    c = (r==0)?(1.0):(x/r);
    s = (r==0)?(0.0):(y/r);
    for (uint i=0; i<size; i++){
      x = data[2*(size*i+j)];
      y = data[2*(size*i+j)+1];
      data[2*(size*i+j)] = x*c + y*s;
      data[2*(size*i+j)+1] = y*c - x*s;
    }
  }
  // Positive phase on (1,1) component
  y = data[2*size+3];
  if (y < 0){
    for (uint i=1; i<size; i++){
      for (uint j=1; j<size; j++){
        data[2*(i*size+j)+1] = -data[2*(i*size+j)+1];
      }
    }
  }
}

void unitary::permute_rows(gsl_permutation p){
  unitary V(size);
  uint idx, jdx;
  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = i*size + j;
      jdx = gsl_permutation_get(&p, i)*size + j;
      V.data[2*idx] = data[2*jdx];      // Real part
      V.data[2*idx+1] = data[2*jdx+1];  // Imaginary part
    }
  }
  *this = V;
}

void unitary::permute_cols(gsl_permutation p){
  unitary V(size);
  uint idx, jdx;
  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = i*size + j;
      jdx = i*size + gsl_permutation_get(&p, j);
      V.data[2*idx] = data[2*jdx];      // Real part
      V.data[2*idx+1] = data[2*jdx+1];  // Imaginary part
    }
  }
  *this = V;
}

void unitary::unfold_rows(){
  gsl_permutation *p = gsl_permutation_alloc(size);
  gsl_permutation_init(p);
  if (size%2){
    // Odd size
    p->data[0] = size/2;
    for (uint i=0; i<size/2; i++){
      p->data[2*i+1] = (size+1)/2-i-2;
      p->data[2*i+2] = (size+1)/2+i;
    }
  }
  else{
    // Even size
    for (uint i=0; i<size/2; i++){
      p->data[2*i] = size/2-i-1;
      p->data[2*i+1] = size/2+i;
    }
  }
  permute_rows(*p);
  gsl_permutation_free(p);
}

void unitary::unfold_cols(){
  gsl_permutation *p = gsl_permutation_alloc(size);
  gsl_permutation_init(p);
  if (size%2){
    // Odd size
    p->data[0] = size/2;
    for (uint i=0; i<size/2; i++){
      p->data[2*i+1] = (size+1)/2-i-2;
      p->data[2*i+2] = (size+1)/2+i;
    }
  }
  else{
    // Even size
    for (uint i=0; i<size/2; i++){
      p->data[2*i] = size/2-i-1;
      p->data[2*i+1] = size/2+i;
    }
  }
  permute_cols(*p);
  gsl_permutation_free(p);
}


void unitary::print(ostream &fout) const{
  // Prints a representation of the matrix to stdout
  double x, y;
  uint idx, jdx;

  fout << "[ ";
  for (uint i=0; i<size; i++){
    fout << "[ ";
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      x = data[idx];
      y = data[jdx];
      fout << CPRINT(x,y) << " ";
    }
    if (i == size-1)
      fout << "] ";
    else
      fout << "]\n  ";
  }
  fout << "]" << endl;
}

void unitary::write(string fname) const{
  // Writes a representation of the matrix to the file "fname"
  ofstream fout;
  double x, y;
  uint idx, jdx;

  fout.open(fname.data());
  fout << showpos;

  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      idx = 2*(i*size + j);
      jdx = idx + 1;
      x = data[idx];
      y = data[jdx];
      fout << x << y << "j ";
    }
    fout << endl;
  }

  fout.close();

  // Orthogonalise the matrix
}


