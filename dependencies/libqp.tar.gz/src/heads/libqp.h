/* libqp.h
 *
 * Helper functions and macros for the quantum photonics classes I'm currently
 * writing */

#ifndef LIBQP_H
#define LIBQP_H

// Macros etc.
#define QUANTUM true
#define CLASSICAL false

// Typedefs
typedef unsigned long ulong;

// Necessary standard libraries
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cfloat>
#include <cmath>
#include <ctime>
#include <complex>

// Necessary gsl libraries
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_multiset.h>
#include <gsl/gsl_complex.h>
#include <gsl/gsl_complex_math.h>
#include <gsl/gsl_combination.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_eigen.h>

// Forward declarations of classes
class fock;
class unitary;
class hermitian;
class reck;

// Helper functions
namespace qp{
  void orthogonalise(gsl_matrix_complex*);
  void printmatrix(uint, double*);
  std::complex<double> cpermanent(uint, double*);
  double permanent(uint, double*);
  unitary expi(hermitian, double t=1);
  //hermitian logi(unitary, double t=1);
  double rng_poly(uint, gsl_rng*);
  hermitian walk(uint nmodes=21);
}

// Headers for my classes
#include "fock.h"
#include "unitary.h"
#include "hermitian.h"
#include "reck.h"

// Macro to print gsl complex numbers
//#define CPRINT(z) "(" << GSL_REAL(z) << "," << GSL_IMAG(z) << ")"
// Macro to print a tuple as a complex number
#define CPRINT(x,y) "(" << x << "," << y << ")"

#endif
