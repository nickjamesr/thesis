#ifndef UNITARY_H
#define UNITARY_H

/* Class unitary
 *
 * Encodes complex unitary matrices.
 *
 * Data encoded as 2*N*N array of doubles for compatibility with CUDA routines.
 * Complex-typed methods return std::complex<double> type
 *
 * All constructors and methods guarantee unitarity
 *
 * Allows interaction with fock, superposition, reck and hermitian objects */

#include "libqp.h"

using namespace std;

class unitary{
  private:
    double *data;             // array containing the data
    uint size;                // Size of the matrix
    // Private methods
    void zero();              // Zero all elements of the matrix (not unitary)
  public:
    // Constructors
    unitary();                // Default constructor
    unitary(uint);            // Initialise to the NxN identity
    unitary(const unitary&);  // Copy constructor
    unitary(const reck&);     // Convert from Reck scheme to unitary
    // Destructor
    ~unitary();               // Ensures memory in gsl is freed
    // Initialisation
    void identity();          // Initialise to the identity
    void haar(ulong);         // Choose Haar-random unitary
    void read(const string);  // Read from a file
    // Overloads
    unitary operator=(const unitary&);
                              // Assignment operator
    unitary operator*(const unitary&) const;
                              // Matrix multiplication with another unitary
    // Amplitudes/evolution
    complex<double> amplitude(const fock&, const fock&, bool quantum=QUANTUM)
        const;
                              // Transition amplitude between two Fock states
    // Public methods
    bool test();              // Test unitarity of matrix
    complex<double> permanent();
                              // Compute the permanent of the unitary (DBG)
    fock sample(const fock&); // Given an input state, sample from output
    uint get_size() const;    // Return the size of the matrix
    double *matrix() const;   // Return a pointer to the data array
    void clean();
    void realborder();        // Convert to the real-bordered form
    void permute_rows(gsl_permutation);
                              // Permute the rows of the matrix
    void permute_cols(gsl_permutation);
                              // Permute the columns of the matrix
    void unfold_rows();       // Permute such that the centre row is at the top,
                              // then rows alternate either side
    void unfold_cols();       // As above, but with columns
    // Output
    void print(ostream &fout=cout) const;
                              // Print a representation of the unitary to stdout
    void write(string) const; // Write the unitary to a file
    friend class reck;
};

#endif
