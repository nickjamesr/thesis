#ifndef HERMITIAN_H
#define HERMITIAN_H

/* Class hermitian
 *
 * Encodes Hermitian matrices. On the lowest level just a wrapper on the gsl
 * complex matrix structure, but also ensures that the matrix is always
 * Hermitian.
 *
 * Allows interaction with unitary objects */

#include "libqp.h"

using namespace std;

class hermitian{
  private:
    double *data;             // array containing the data
    uint size;                // size of the matrix
  public:
    // Constructors
    hermitian();              // Default constructor
    hermitian(uint);          // Initialise to the NxN identity
    hermitian(const hermitian&);
                              // Copy constructor
    // Destructor
    ~hermitian();             // Ensures memory in matrix is freed
    // Initialisation
    void identity();          // Initialises elements to the identity
    void gaussian(ulong);     // Initialise to iid Gaussians
    void read(const string);  // Read the matrix from file
    // Overloads
    hermitian operator=(const hermitian&);
                              // Assignment operator
    hermitian operator+(const hermitian&);
                              // Addition of Hermitian matrices
    hermitian operator*(const double&);
                              // Multiplication by a real constant
    // Public methods
    uint get_size() const;    // Return the size of the matrix
    double* matrix() const;   // Return a pointer to the data array
    // Output
    void print(ostream &fout=cout) const;
                              // Print a representation of the matrix to fout
    void write(const string) const;
                              // Write a representation of the matrix to file
};

#endif
