#ifndef FOCK_H
#define FOCK_H

/* Class fock
 *
 * Encodes p-photon, m-mode Fock states. Basically just an implementation of a
 * multiset structure */

#include "libqp.h"

using namespace std;

class fock{
  private:
    uint m;                   // Number of modes
    uint p;                   // Number of photons
    uint *state;              // Array containing the state
  public:
    // Constructors
    fock();                   // Default constructor
    fock(uint, uint);         // Initialise to default state
    fock(uint, uint, uint*);  // Initialise to a specific state
    fock(const fock&);        // Copy constructor
    // Destructor
    ~fock();
    // Private methods
    bool valid() const;       // Test if the state is a valid description
    // Initiation
    void random(ulong);       // Initiate to a random state
    void random_noreps(ulong);// As above but with no repeated photons
    // Overloads
    fock& operator=(const fock&);
                              // Assignment operator
    // Public methods
    uint n_photons() const;   // return number of photons
    uint n_modes() const;     // return number of modes
    uint photon(uint) const;  // returns the position of the n-th photon
    int prev();               // sets the state to the previous Fock state
    int prev_noreps();        // as above, but no repeated photons
    int next();               // sets the state to the next Fock state
    int next_noreps();               // as above, but no repeated photons
                              // The above return 1 if successful, 0 otherwise
    void print(ostream &fout=cout) const;       
    // Print a representation of the state to stdout
    bool contains(uint, bool atleast=0) const;
};

#endif
