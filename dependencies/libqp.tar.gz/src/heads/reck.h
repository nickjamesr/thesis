#ifndef RECK_H
#define RECK_H

/* Class reck
 *
 * Encodes the Reck decomposition of matrices. At the lowest level just a
 * wrapper on the gsl real matrix class. Beamsplitter reflectivities are stored
 * in the upper triangle, phase shifts are stored in the lower triangle (except
 * the input phases which are stored on the diagonal). See TODO <documentation>
 * for more information
 *
 * Allows interaction with unitary objects */

#include "libqp.h"

using namespace std;

class reck{
  private:
    double *data;             // array containing the data
    uint size;                // size of the matrix
  public:
    // Constructors
    reck();                   // Default constructor
    reck(uint);               // Initialise to the NxN identity
    reck(const reck&);        // Copy constructor
    reck(const unitary&);     // Get the Reck scheme representation of a unitary
    // Destructor
    ~reck();                  // Ensures memory in gsl matrix is freed
    // Initialisation
    void identity();          // Set the Reck scheme to an identity matrix
    void haar(ulong);         // Set the Reck scheme to a Haar-random unitary
    // Overloads
    reck operator=(const reck&);
                              // Assignment operator
    // Public methods
    double get_r(uint, uint) const;
                              // Returns the specified reflectivity
    double get_phi(uint, uint) const;
                              // Returns the specified phase shift
    double get_alpha(uint) const;
                              // Returns the specified input phase
    void set_r(uint, uint, double);
    void set_phi(uint, uint, double);
    void set_alpha(uint, double);
    uint get_size() const;    // Return the size of the matrix
    double *matrix() const;   // Return a pointer to the data array
    void truncate(uint);      // Truncate to mxn scheme (m<n)
    // Output
    void print(ostream &fout=cout) const;
                              // Print a representation of the matrix to stdout
    void write(const string) const;
                              // Write a representation to a file
};

#endif
