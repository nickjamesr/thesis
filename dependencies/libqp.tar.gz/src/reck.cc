#include "heads/libqp.h"

using namespace std;

reck::reck(){
  // Default (empty) constructor
  size = 0;
}

reck::reck(uint N){
  // Identity constructor. Returns the NxN identity matrix
  size = N;
  data = new double[N*N];
  identity();
}

reck::reck(const reck& R){
  // Copy constructor
  size = R.size;
  data = new double[size*size];
  memcpy(data, R.data, size*size*sizeof(double));
}

reck::reck(const unitary& U){
  // Get the Reck scheme representation of a unitary
  unitary V(U);
  uint idx, p, q, pk, qk;
  double x, y, alpha, r, phi, cosp, sinp, pir, pii, qir, qii;
  double cosw, sinw, pkr, pki, qkr, qki;

  size = U.get_size();
  data = new double[size*size];
  //memcpy(V.matrix(), U.matrix(), 2*size*size*sizeof(double));

  for (uint i=0; i<(size-1); i++){
    // Looking at i-th column of matrix
    idx = 2*((size-1)*size + i);
    x = V.matrix()[idx];
    y = V.matrix()[idx+1];
    // Calculate alpha_{i}
    alpha = atan2(y,x);
    set_alpha(i, alpha);
    // Calculate U_{i}
    for (uint j=(i+1); j<size; j++){
      q = size+i-j;
      p = q-1;
      // Calculate u_{ij}
      // p-th and q-th rows of matrix
      idx = 2*(p*size + i);
      pir = V.matrix()[idx];
      pii = V.matrix()[idx+1];
      idx = 2*(q*size + i);
      qir = V.matrix()[idx];
      qii = V.matrix()[idx+1];
      // Get phase
      phi = atan2(pii, pir) - alpha;
      if (phi<-M_PI)
        phi += (2*M_PI);
      else if (phi>M_PI)
        phi -= (2*M_PI);
      set_phi(i,j,phi);
      sinp = sin(phi);
      cosp = cos(phi);
      // Get reflectivity
      x = pir*pir + pii*pii;
      y = qir*qir + qii*qii;
      if ((x+y)!=0)
        r = x/(x+y);
      else
        r = 1;
      set_r(i,j,r);
      cosw = sqrt(r);
      sinw = sqrt(1-r);
      // Pre-multiply by inverse matrix
      for (uint k=0; k<size; k++){
        pk = 2*(p*size + k);
        qk = 2*(q*size + k);
        pkr = V.matrix()[pk];
        pki = V.matrix()[pk+1];
        qkr = V.matrix()[qk];
        qki = V.matrix()[qk+1];
        V.matrix()[pk] = cosw*cosp*pkr + cosw*sinp*pki + sinw*qkr;
        V.matrix()[pk+1] = cosw*cosp*pki - cosw*sinp*pkr + sinw*qki;
        V.matrix()[qk] = sinw*cosp*pkr + sinw*sinp*pki - cosw*qkr;
        V.matrix()[qk+1] = sinw*cosp*pki - sinw*sinp*pkr - cosw*qki;
      }
    }
  }
  // Get final phase
  x = V.matrix()[2*(size*size-1)];
  y = V.matrix()[2*(size*size)-1];
  alpha = atan2(y,x);
  set_alpha(size-1, alpha);
}

reck::~reck(){
  // Destructor: ensures that the matrix memory is freed
  if (size)
    delete[] data;
}

void reck::identity(){
  // Set the Reck scheme to an identity matrix
  for (uint i=0; i<(size-1); i++){
    if (i%2){
      set_alpha(i,M_PI);
    }
    for (uint j=(i+1); j<size; j++){
      set_r(i,j,1);
      set_phi(i,j,0);
    }
  }
  if (size%2==0){
    set_alpha(size-1, M_PI);
  }
}

void reck::haar(ulong seed){
  // Set the Reck scheme to a Haar-random unitary (directly)
  cerr << "Direct dialling of random matrices not yet implemented" << endl;
  gsl_rng *r = gsl_rng_alloc(gsl_rng_ranlxd2);
  gsl_rng_set(r, seed);
  double rho, phi, alpha;

  for (uint i=0; i<size-1; i++){
    for (uint j=i+1; j<size; j++){
      phi = 2.0*M_PI*gsl_rng_uniform(r);
      rho = qp::rng_poly(j-1, r);
      this->set_r(i, j, rho);
      this->set_phi(i, j, phi);
    }
    alpha = 2.0*M_PI*gsl_rng_uniform(r);
    this->set_alpha(i, alpha);
  }

  gsl_rng_free(r);
}

reck reck::operator=(const reck& R){
  // Copy constructor
  if (size)
    delete[] data;

  size = R.size;
  data = new double[size*size];
  memcpy(data, R.data, size*size*sizeof(double));

  return *this;
}

double reck::get_r(uint i, uint j) const{
  // Return r_[i,j]
  return data[i*size+j];
}

double reck::get_phi(uint i, uint j) const{
  // Return phi_[i,j]
  return data[j*size+i];
}

double reck::get_alpha(uint i) const{
  // Return alpha_[i]
  return data[i*(size+1)];
}

void reck::set_r(uint i, uint j, double r){
  // Set r_{ij}
  data[i*size+j] = r;
}

void reck::set_phi(uint i, uint j, double phi){
  // Set phi_{ij}
  data[j*size+i] = phi;
}

void reck::set_alpha(uint i, double alpha){
  // Set alpha_{i}
  data[i*size + i] = alpha;
}

uint reck::get_size() const{
  return size;
}

double* reck::matrix() const{
  return data;
}

void reck::truncate(uint m){
  if (m>size){
    cerr << "Invalid truncation" << endl;
  }
  for (uint i=m; i<size-1; i++){
    for (uint j=i+1; j<size; j++){
      this->set_r(i, j, 1.0);
      this->set_phi(i, j, 0);
    }
    this->set_alpha(i, 0);
    //TODO: make this alternate sign as necessary
  }
}

void reck::print(ostream &fout) const{
  // Prints a representation of the matrix to stdout
  uint idx=0;

  fout << "[ ";
  for (uint i=0; i<size; i++){
    fout << "[ ";
    for (uint j=0; j<size; j++){
      fout << data[idx] << " ";
      idx++;
    }
    if (i == size-1)
      fout << "] ";
    else
      fout << "]\n  ";
  }
  fout << "]" << endl;
}

double principal(double x){
  return (x>0)?(x):(2.0*M_PI + x);
}

void reck::write(const string fname) const{
  // Writes a representation of the matrix to the file "fname"
  ofstream fout;
  fout.open(fname.data());
  fout << showpos;

  // Write reflectivities
  fout << "\nReflectivities" << endl;
  for (uint i=0; i<size-1; i++){
    for (uint j=i+1; j<size; j++){
      fout << this->get_r(i,j) << " ";
    }
    fout << endl;
  }

  // Write internal phases
  fout << "\nInternal phases" << endl;
  for (uint i=0; i<size-1; i++){
    for (uint j=i+1; j<size; j++){
      fout << principal(this->get_phi(i,j))/(M_PI) << " ";
    }
    fout << endl;
  }

  // Write input phases
  fout << "\nInput phases" << endl;
  for (uint i=0; i<size; i++){
    fout << principal(this->get_alpha(i))/(M_PI) << " ";
  }
}






