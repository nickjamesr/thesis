#!/usr/bin/python

import gtk, gobject

import numpy as np
import scipy.optimize as opt

from sys import argv, exit
from os import path
from matplotlib.backends.backend_gtkagg import FigureCanvasGTKAgg as\
  FigureCanvas
from matplotlib.figure import Figure

### Usage message
def usage():
  print '''\
Usage: crapusoid.py <fname>
       <fname> = filename of datafile
'''

### Define fit functions
  # Crapusoids
def skewed_cos(x,A,d,beta,eps,r):
  return A*(1+np.cos(2*phi(x,beta,eps,r))) + d
def skewed_sin(x,A,d,beta,eps,r):
  return A*(1-np.cos(2*phi(x,beta,eps,r))) + d
def phi(x,beta,eps,r):
  return (x-beta-eps*np.cos((x-r)*np.pi/180))*np.pi/180
  # Linear fit function
def lin(x,m,c):
  return m*x + c
  # Sinusoid
def sin(x,A,d,x0):
  return A*np.cos((x-x0)*np.pi/180) + d

### GUI class
class Fitter:
  # Necessary gtk behaviour
  def quitApp(self,widget,data=None):
    gtk.main_quit()
    return False

  def main(self):
    gtk.main()

  # What do I want it to be able to do?
  def getData(self,fname):
    self.data = np.loadtxt(fname, skiprows=1, usecols=(0,1,2,3,4))

  def getInitialParams(self):
    self.paramA = 0.5*(max(self.data[:,self.idx])-min(self.data[:,self.idx]))
    self.valueA.set_text("{0:4g}".format(self.paramA))
    self.paramD = min(self.data[:,self.idx])
    self.valueD.set_text("{0:4g}".format(self.paramD))
    self.paramBeta = 100
    self.valueBeta.set_text("{0:4g}".format(self.paramBeta))
    self.paramEps = 20
    self.valueEps.set_text("{0:4g}".format(self.paramEps))
    self.paramR = 50
    self.valueR.set_text("{0:4g}".format(self.paramR))

  def readParams(self,widget,data=None):
    self.paramA = float(self.valueA.get_text())
    self.paramD = float(self.valueD.get_text())
    self.paramBeta = float(self.valueBeta.get_text())
    self.paramEps = float(self.valueEps.get_text())
    self.paramR = float(self.valueR.get_text())
    self.plotData()

  def plotData(self):
    self.ax.cla()
    self.ax.plot(self.data[:,0],self.data[:,self.idx],'r+')
    self.ax.plot(self.data[:,0],self.fitFunction((self.data[:,0]),\
      self.paramA, self.paramD, self.paramBeta, self.paramEps, self.paramR),\
      'g-')
    self.ax.set_xlim(0,360)
    self.ax.set_xlabel("R2 position")
    self.ax.set_ylabel(self.labels[self.idx-1])
    self.canvas.draw()

  def plotPhases(self,widget,data=None):
    if widget.get_active() and None not in self.fitParams:
      xvals = self.data[:,0]
      self.ax.cla()
      self.linvals = phi(xvals,*(self.fitParams[0][2:]))+\
        phi(xvals,*(self.fitParams[1][2:]))+\
        phi(xvals,*(self.fitParams[2][2:]))+\
        phi(xvals,*(self.fitParams[3][2:]))
      self.sinvals = phi(xvals,*(self.fitParams[0][2:]))+\
        phi(xvals,*(self.fitParams[1][2:]))-\
        phi(xvals,*(self.fitParams[2][2:]))-\
        phi(xvals,*(self.fitParams[3][2:]))
      self.ax.plot(xvals,self.linvals,'r+')
      self.ax.plot(xvals,self.sinvals,'g+')
      popt,pcov = opt.curve_fit(lin,xvals,self.linvals,p0=(0.1,-5))
      m,c = popt
      popt,pcov = opt.curve_fit(sin,xvals,self.sinvals,p0=(2,-5,90))
      A,d,x0 = popt
      self.ax.plot(xvals,lin(xvals,m,c),'r-')
      self.ax.plot(xvals,sin(xvals,A,d,x0),'g-')
      self.ax.set_xlim(0,360)
      self.canvas.draw()
    elif None in self.fitParams:
      widget.set_active(True)
    else:
      self.plotData()

  def calculatePhases(self,widget,data=None):
    if None in (self.linvals,self.sinvals):
      pass
    else:
      xvals = self.data[:,0]
      phi1 = float(self.valuePhi1.get_text())
      phi2 = float(self.valuePhi2.get_text())
      popt,pcov = opt.curve_fit(lin,xvals,self.linvals,p0=(0.1,-5))
      m,c = popt
      popt,pcov = opt.curve_fit(sin,xvals,self.sinvals,p0=(2,-5,90))
      A,d,x0 = popt
      r2 = phi2 + c
      r3 = phi1 + A*np.cos((r2-x0)*np.pi/180) + d
      self.calculatedPhi1.set_text("R3 = {0:.2f}".format(r3))
      self.calculatedPhi2.set_text("R2 = {0:.2f}".format(r2))

  def makeControlBox(self):
    self.controlBox = gtk.HBox()

    self.exitButton = gtk.Button(label="Exit")
    self.exitButton.connect("clicked", self.quitApp)
    self.replotButton = gtk.Button(label="Replot")
    self.replotButton.connect("clicked", self.readParams)

    self.controlBox.pack_start(self.exitButton)
    self.controlBox.pack_start(self.replotButton)

  def changeIdx(self,widget,data=None):
    self.idx = self.comboSelect.get_active()+1
    if self.idx%2 == 1:
      self.fitFunction = skewed_cos
    else:
      self.fitFunction = skewed_sin
    self.getInitialParams()
    self.plotData()

  def fitCrapusoid(self,widget,data=None):
    popt, pcov = opt.curve_fit(self.fitFunction,self.data[:,0],\
      self.data[:,self.idx],p0=(self.paramA,self.paramD,self.paramBeta,\
      self.paramEps,self.paramR))
    self.paramA = popt[0]
    self.valueA.set_text("{0:.4g}".format(self.paramA))
    self.paramD = popt[1]
    self.valueD.set_text("{0:.4g}".format(self.paramD))
    self.paramBeta = popt[2]
    self.valueBeta.set_text("{0:.4g}".format(self.paramBeta))
    self.paramEps = popt[3]
    self.valueEps.set_text("{0:.4g}".format(self.paramEps))
    self.paramR = popt[4]
    self.valueR.set_text("{0:.4g}".format(self.paramR))
    self.fitParams[self.idx-1] = popt
    self.plotData()
    if None not in self.fitParams:
      self.showButton.set_active(False)


  # Packing and other housekeeping
  def makeParamsBox(self):
    self.paramsBox = gtk.VBox()

    self.labelSelect = gtk.Label("Show channel")
    self.comboSelect = gtk.combo_box_new_text()
    self.comboSelect.append_text("A")
    self.comboSelect.append_text("B")
    self.comboSelect.append_text("C")
    self.comboSelect.append_text("D")
    self.comboSelect.set_active(0)
    self.comboSelect.connect("changed", self.changeIdx)
    self.boxSelect = gtk.HBox()
    self.boxSelect.pack_start(self.labelSelect)
    self.boxSelect.pack_start(self.comboSelect,expand=False)

    self.valueA = gtk.Entry()
    self.valueA.connect("activate", self.readParams)
    self.labelA = gtk.Label("A = ")
    self.labelA.set_justify(gtk.JUSTIFY_RIGHT)
    self.labelA.set_width_chars(7)
    self.boxA = gtk.HBox()
    self.boxA.pack_start(self.labelA,fill=True)
    self.boxA.pack_start(self.valueA,expand=False)

    self.valueD = gtk.Entry()
    self.valueD.connect("activate", self.readParams)
    self.labelD = gtk.Label("d = ")
    self.labelD.set_justify(gtk.JUSTIFY_RIGHT)
    self.labelD.set_width_chars(7)
    self.boxD = gtk.HBox()
    self.boxD.pack_start(self.labelD,fill=True)
    self.boxD.pack_start(self.valueD,expand=False)
  
    self.valueBeta = gtk.Entry()
    self.valueBeta.connect("activate", self.readParams)
    self.labelBeta = gtk.Label("beta = ")
    self.labelBeta.set_justify(gtk.JUSTIFY_RIGHT)
    self.labelBeta.set_width_chars(7)
    self.boxBeta = gtk.HBox()
    self.boxBeta.pack_start(self.labelBeta,fill=True)
    self.boxBeta.pack_start(self.valueBeta,expand=False)
  
    self.valueEps = gtk.Entry()
    self.valueEps.connect("activate", self.readParams)
    self.labelEps = gtk.Label("eps = ")
    self.labelEps.set_justify(gtk.JUSTIFY_RIGHT)
    self.labelEps.set_width_chars(7)
    self.boxEps = gtk.HBox()
    self.boxEps.pack_start(self.labelEps,fill=True)
    self.boxEps.pack_start(self.valueEps,expand=False)
  
    self.valueR = gtk.Entry()
    self.valueR.connect("activate", self.readParams)
    self.labelR = gtk.Label("r = ")
    self.labelR.set_justify(gtk.JUSTIFY_RIGHT)
    self.labelR.set_width_chars(7)
    self.boxR = gtk.HBox()
    self.boxR.pack_start(self.labelR,fill=True)
    self.boxR.pack_start(self.valueR,expand=False)

    self.fitButton = gtk.Button("Fit")
    self.fitButton.connect("clicked", self.fitCrapusoid)

    self.showButton = gtk.ToggleButton("Show Phases")
    self.showButton.set_active(True)
    self.showButton.connect("toggled", self.plotPhases)

    self.labelPhi1 = gtk.Label("pt1")
    self.valuePhi1 = gtk.Entry(max=6)
    self.valuePhi1.set_width_chars(6)
    self.calculatedPhi1 = gtk.Label("R3 = ---")
    self.boxPhi1 = gtk.VBox()
    self.boxPhi1.pack_start(self.labelPhi1)
    self.boxPhi1.pack_start(self.valuePhi1)
    self.boxPhi1.pack_start(self.calculatedPhi1)
    
    self.labelPhi2 = gtk.Label("pt2")
    self.valuePhi2 = gtk.Entry(max=6)
    self.valuePhi2.set_width_chars(6)
    self.calculatedPhi2 = gtk.Label("R2 = ---")
    self.boxPhi2 = gtk.VBox()
    self.boxPhi2.pack_start(self.labelPhi2)
    self.boxPhi2.pack_start(self.valuePhi2)
    self.boxPhi2.pack_start(self.calculatedPhi2)

    self.boxPhases = gtk.HBox()
    self.boxPhases.pack_start(self.boxPhi1)
    self.boxPhases.pack_start(self.boxPhi2)
 
    self.calcButton = gtk.Button("Calculate")
    self.calcButton.connect("clicked",self.calculatePhases)

    self.paramsBox.pack_start(self.boxSelect,expand=False,padding=10)
    self.paramsBox.pack_start(self.boxA,expand=False,padding=10)
    self.paramsBox.pack_start(self.boxD,expand=False,padding=10)
    self.paramsBox.pack_start(self.boxBeta,expand=False,padding=10)
    self.paramsBox.pack_start(self.boxEps,expand=False,padding=10)
    self.paramsBox.pack_start(self.boxR,expand=False,padding=10)
    self.paramsBox.pack_start(self.fitButton,expand=False,padding=0)
    self.paramsBox.pack_start(self.showButton,expand=False,padding=0)
    self.paramsBox.pack_start(self.boxPhases,expand=False,padding=10)
    self.paramsBox.pack_start(self.calcButton,expand=False,padding=0)

  # Constructor (these are a nightmare in gtk)
  def __init__(self,fname):
    self.fname = fname
    self.idx = 1
    self.getData(self.fname)
    self.labels = ("A", "B", "C", "D")
    self.fitFunction = skewed_cos
    self.fitParams = [None, None, None, None]
    self.linvals = None
    self.sinvals = None
    # GUI window management
    self.win = gtk.Window()
    self.win.connect("destroy", lambda x:gtk.main_quit())
    self.win.set_default_size(800,600)
    self.win.set_title("Crapusiod Fitting")
    # Fitting window
    self.fig = Figure(figsize=(10,8),dpi=80, facecolor="white")
    self.ax = self.fig.add_subplot(111)
    self.canvas = FigureCanvas(self.fig)
    # Pack everything in
    self.makeControlBox()
    self.makeParamsBox()
    self.plotBox = gtk.HBox()
    self.plotBox.pack_start(self.canvas)
    self.plotBox.pack_start(self.paramsBox,expand=False)
    self.mainBox = gtk.VBox()
    self.mainBox.pack_start(self.plotBox)
    self.mainBox.pack_start(self.controlBox, expand=False)
    self.win.add(self.mainBox)
    # Plot, show window, etc.
    self.getInitialParams()
    self.plotData()
    self.win.show_all()
    
if __name__=='__main__':
  try:
    fname = argv[1]
  except:
    usage()
    exit(1)
  fittie = Fitter(fname)
  fittie.main()




