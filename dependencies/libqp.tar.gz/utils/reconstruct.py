#!/usr/bin/python

import math
import cmath

import numpy as np
import scipy.optimize as opt

from matplotlib import pyplot
from fitting_gui import Fittie
from os import path
from sys import argv

def time(n):
  if (n < 20):
    return (n-1)/3.0
  else:
    return 30+(n-20)/5.0

def abs2(x):
  return abs(x)**2

def principal(x, base=math.pi):
  return 2*base*(((x+base)/(2*base))%1)-base

def getEfficiencies(num):
  path = "data/{0:02}/".format(num)
  names = ["background", "A", "B", "C", "D"]
  counts = []
  for i in range(5):
    fin = open(path+names[i]+".txt", 'r')
    counts.append([int(x) for x in fin.readline().strip('[] \n\r').split()])
  counts = np.array(counts)
  adjusted = np.array([counts[i]-counts[0] for i in range(1,5)])
  eta = np.array([counts[1,0]/float(counts[i+1,i]) for i in range(4)])
  return eta

def realBorder(U):
  for i in range(4):
    phi = cmath.phase(U[i,0])
    U[i,0] *= np.exp(complex(0,-phi))
    U[i,1] *= np.exp(complex(0,-phi))
  phi = cmath.phase(U[0,1])
  for i in range(4):
    U[i,1] *= np.exp(complex(0,-phi))
  return U

def visibility(U,i,j):
  quantum = abs2(U[i,0]*U[j,1] + U[j,0]*U[i,1])
  classical = abs2(U[i,0]*U[j,1]) + abs2(U[j,0]*U[i,1])
  if (classical==0):
    return 0
  else:
    return (classical-quantum)/classical

def dVis(phi, b_exp, v_exp):
  pairs = ((0,1),(0,2),(0,3),(1,2),(1,3),(2,3))
  v_exp = np.array([v_exp[i,j] for (i,j) in pairs])
  phi = [0,phi[0],phi[1],phi[2]]
  cosines = np.array([math.cos(phi[i]-phi[j]) for (i,j) in pairs])
  b_mod = np.array([b_exp[i,j] for (i,j) in pairs])
  v_mod = -2*cosines/(b_mod + 1.0/b_mod)
  return sum((v_exp-v_mod)**2)

if __name__=='__main__':
  num = int(argv[-1])
  plot = False
  save = False
  if "-p" in argv:
    plot = True
  if "-s" in argv:
    save = True

### Get Necessary data from files ###
  folder = "data/{0:02}".format(num)
  if not path.exists(folder+"/mat{0:02}.dat".format(num)):
    print "No file for matrix {0:02}".format(num)
    exit(1)
  if not path.exists(folder+"/dip{0:02}.dat".format(num)):
    print "No dip for matrix {0:02}".format(num)
    exit(1)
  if not (path.exists(folder+"/A.txt") and path.exists(folder+"/C.txt") and \
path.exists(folder+"/B.txt") and path.exists(folder+"/D.txt") and \
path.exists(folder+"/background.txt")):
    print "No efficiency data for matrix {0:02}".format(num)
    exit(1)
  if not path.exists(folder+"/params{0:02}.dat".format(num)):
    fittie = Fittie(num)
    fittie.main()
  dips = np.loadtxt(folder+"/params{0:02}.dat".format(num))

  matrix = np.loadtxt(folder+"/mat{0:02}.dat".format(num),\
      dtype=complex)[0:4,0:2]
  matrix = realBorder(matrix)
  qin = abs2(matrix[:,0])
  tin = abs2(matrix[:,1])

  blocking = np.loadtxt(folder+"/dip{0:02}.dat".format(num),\
      usecols=(1,2,3,4))[0:6]
  background = blocking[0,:]
  quart = blocking[2,:]-background
  trit = blocking[4,:]-background
  for i in range(4):
    quart[i] = max(1,quart[i])
    trit[i] = max(1,trit[i])
### Got data - now start processing ###

  eta = getEfficiencies(num)

  # Adjust quart and trit for efficiencies and normalise to 1
  quart_err = np.sqrt(quart)
  trit_err = np.sqrt(trit)
  quart_err = quart_err*eta/sum(quart*eta)
  quart = quart*eta/sum(quart*eta)
  trit_err = trit_err*eta/sum(trit*eta)
  trit = trit*eta/sum(trit*eta)

  # Blocking data (loss invariants)
  B_exp = np.sqrt(np.array([[quart[i]*trit[j]/(quart[j]*trit[i])\
      for i in range(4)] for j in range(4)]))

  vis_exp = np.array([[-1,dips[0,0],dips[1,0],dips[2,0]],\
      [dips[0,0],-1,dips[3,0],dips[4,0]],\
      [dips[1,0],dips[3,0],-1,dips[5,0]],\
      [dips[2,0],dips[4,0],dips[5,0],-1]])
  quant_exp = np.array([[-1,dips[0,1],dips[1,1],dips[2,1]],\
      [dips[0,1],-1,dips[3,1],dips[4,1]],\
      [dips[1,1],dips[3,1],-1,dips[5,1]],\
      [dips[2,1],dips[4,1],dips[5,1],-1]])
  class_exp = np.array([[-1,dips[0,2],dips[1,2],dips[2,2]],\
      [dips[0,2],-1,dips[3,2],dips[4,2]],\
      [dips[1,2],dips[3,2],-1,dips[5,2]],\
      [dips[2,2],dips[4,2],dips[5,2],-1]])
  
  cosines_exp = -0.5*vis_exp*(B_exp+1/B_exp)
  # Force cosines into range [-1:1]
  for i in range(4):
    for j in range(4):
      if cosines_exp[i,j] < -1:
        cosines_exp[i,j] = -1
      elif cosines_exp[i,j] > 1:
        cosines_exp[i,j] = 1
  phi_exp = np.array([[math.acos(cosines_exp[i,j]) for i in range(4)] for j in
    range(4)])
  
### Find phases by optimisation (accounting for signs)
  modphi_exp = phi_exp[0,1:4]
  dphi_exp = phi_exp[1,2:4]
  sgn_exp = (1,1)

  phi_ide = np.array([cmath.phase(x) for x in matrix[1:4,1]])
  vis_ide = np.array([[visibility(matrix, i, j) for i in range(4)]\
      for j in range(4)])

  phi_init = [modphi_exp[0], modphi_exp[1], modphi_exp[2]]
  diff = dVis(phi_init, B_exp, vis_exp)
  for sgn in ((1,1),(1,-1),(-1,1),(-1,-1)):
    phi_init = [modphi_exp[0], sgn[0]*modphi_exp[1],\
        sgn[1]*modphi_exp[2]]
    phi_opt = opt.fmin(dVis, phi_init, args=(B_exp, vis_exp), disp=0)
    if dVis(phi_opt, B_exp, vis_exp) < diff:
      diff = dVis(phi_opt, B_exp, vis_exp)
      sgn_exp = sgn
      phi_exp = phi_opt
  phi_exp = principal(phi_exp)
  if phi_exp[0] < 0:
    phi_exp = -phi_exp
  phi_conj = -phi_exp

### Phases done - find reconstructed matrix and complex conjugate ###

  U_recon = np.array([[math.sqrt(quart[0]), math.sqrt(trit[0])],\
      [math.sqrt(quart[1]), math.sqrt(trit[1])*np.exp(complex(0,phi_exp[0]))],\
      [math.sqrt(quart[2]), math.sqrt(trit[2])*np.exp(complex(0,phi_exp[1]))],\
      [math.sqrt(quart[3]), math.sqrt(trit[3])*np.exp(complex(0,phi_exp[2]))]],\
      dtype=complex)
  U_conj = np.array([[math.sqrt(quart[0]), math.sqrt(trit[0])],\
      [math.sqrt(quart[1]), math.sqrt(trit[1])*np.exp(complex(0,phi_conj[0]))],\
      [math.sqrt(quart[2]), math.sqrt(trit[2])*np.exp(complex(0,phi_conj[1]))],\
      [math.sqrt(quart[3]), math.sqrt(trit[3])*\
      np.exp(complex(0,phi_conj[2]))]], dtype=complex)

### Find some fidelities (of the trace distance variety) ###
  qq = np.vdot(U_recon[:,0], matrix[:,0])
  tt = np.vdot(U_recon[:,1], matrix[:,1])
  qt = np.vdot(U_recon[:,1], U_recon[:,0])
  f_recon = abs2(0.5*(qq+tt))
  f_recon_adj = abs2(0.5*(abs(qq)+abs(tt)))

  tt = np.vdot(U_conj[:,1], matrix[:,1])
  qt = np.vdot(U_conj[:,1], U_conj[:,0])
  f_conj = abs2(0.5*(qq+tt))
  f_conj_adj = abs2(0.5*(abs(qq)+abs(tt)))


### TEMP ###
  # Error bars for singles - need to be defined higher up
  #quart_err = [0 for i in range(4)]
  #trit_err = [0 for i in range(4)]

### Bar chart fidelities ###
  pairs = ((0,1), (0,2), (0,3), (1,2), (1,3), (2,3))
  eps = np.array([eta[i]*eta[j] for (i,j) in pairs])

### Get error bars for coincidences
  quantum_err = np.sqrt(dips[:,2])/sum(dips[:,2]*eps)
  classical_err = np.sqrt(dips[:,1])/sum(dips[:,1]*eps)

### Normalise so sum of 6 coincidences equal to 1
  '''classical_ide = np.array([abs2(matrix[i,0]*matrix[j,1]) +\
      abs2(matrix[j,0]*matrix[i,1]) for (i,j) in pairs])
  classical_ide = classical_ide/sum(classical_ide)
  classical_exp = dips[:,1]*eps/sum(dips[:,1]*eps)

  quantum_ide = np.array([abs2(matrix[i,0]*matrix[j,1] +\
      matrix[j,0]*matrix[i,1]) for (i,j) in pairs])
  quantum_ide = quantum_ide/sum(quantum_ide)
  quantum_exp = dips[:,2]*eps/sum(dips[:,2]*eps)'''

### Normalise so sum of 10 coincidences equal to 1
  classical_ide = np.array([abs2(matrix[i,0]*matrix[j,1]) +\
      abs2(matrix[j,0]*matrix[i,1]) for (i,j) in pairs])
  classical_exp = dips[:,1]*eps/sum(dips[:,1]*eps)
  classical_exp = classical_exp*sum(classical_ide)
  classical_err = classical_err*sum(classical_ide)

  quantum_ide = np.array([abs2(matrix[i,0]*matrix[j,1] +\
      matrix[j,0]*matrix[i,1]) for (i,j) in pairs])
  quantum_exp = dips[:,2]*eps/sum(dips[:,2]*eps)
  quantum_exp = quantum_exp*sum(quantum_ide)
  quantum_err = quantum_err*sum(quantum_ide)

  fout = open("data/{0:02}/reconstructed{0:02}.dat".format(num), 'w')
  for i in range(4):
    fout.write("{0:.5f}{1:+.5f}j {2:.5f}{3:+.5f}j\n".format(U_recon[i,0].real,\
        U_recon[i,0].imag, U_recon[i,1].real, U_recon[i,1].imag))
  fout.close()

  f_quart = 1-0.5*sum(abs(quart-qin))
  f_trit = 1-0.5*sum(abs(trit-tin))
  f_class = 1-0.5*sum(abs(classical_ide-classical_exp))
  f_quantum = 1-0.5*sum(abs(quantum_ide-quantum_exp))

  #print num, max(f_conj,f_recon), "\t", \
  #  f_class, "\t", f_quantum
  print num, max(f_conj_adj,f_recon_adj), "\t", \
    f_class, "\t", f_quantum

  if plot:
    pyplot.title("Quart amplitudes (F={0:.3f})".format(f_quart))
    for i in range(4):
      pyplot.bar(i+0.1, quart[i], width=0.4, color="red")
      pyplot.bar(i+0.5, qin[i], width=0.4, color="green")
    pyplot.show()
    pyplot.title("Trit amplitudes (F={0:.3f})".format(f_trit))
    for i in range(4):
      pyplot.bar(i+0.1, trit[i], width=0.4, color="red")
      pyplot.bar(i+0.5, tin[i], width=0.4, color="green")
    pyplot.show()
    pyplot.title("Classical coincidences (F={0:.3f})".format(f_class))
    for i in range(6):
      pyplot.bar(i+0.1, classical_exp[i], width=0.4, color="red")
      pyplot.bar(i+0.5, classical_ide[i], width=0.4, color="green")
    pyplot.show()
    pyplot.title("Quantum coincidences (F={0:.3f})".format(f_quantum))
    for i in range(6):
      pyplot.bar(i+0.1, quantum_exp[i], width=0.4, color="red")
      pyplot.bar(i+0.5, quantum_ide[i], width=0.4, color="green")
    pyplot.show()

  quart = np.append(quart, quart_err)
  trit = np.append(trit, trit_err)
  quantum_exp = np.append(quantum_exp, quantum_err)
  classical_exp = np.append(classical_exp, classical_err)

  qin = np.append(qin, [0 for i in range(4)])
  tin = np.append(tin, [0 for i in range(4)])
  quantum_ide = np.append(quantum_ide, [0 for i in range(6)])
  classical_ide = np.append(classical_ide, [0 for i in range(6)])

  if save:
### Quart
  # Experimental
    fstring = ""
    for i in range(9):
      fstring += "{" + str(i) + ":.4f} "
    fstring += "\n"
    fout = open("quart_exp.dat", 'a')
    #fout.write(fstring.format(time(num), *quart))
    fout.write(fstring.format(num, *quart))
    fout.close()
  # Ideal
    fout = open("quart_ide.dat", 'a')
    #fout.write(fstring.format(time(num), *qin))
    fout.write(fstring.format(num, *qin))
    fout.close()
### Trit
  # Experimental
    fout = open("trit_exp.dat", 'a')
    #fout.write(fstring.format(time(num), *trit))
    fout.write(fstring.format(num, *trit))
    fout.close()
  # Ideal
    fout = open("trit_ide.dat", 'a')
    #fout.write(fstring.format(time(num), *tin))
    fout.write(fstring.format(num, *tin))
    fout.close()

    fstring = ""
    for i in range(13):
      fstring += "{" + str(i) + ":.4f} "
    fstring += "\n"
### Quantum
  # Experimental
    fout = open("quant_exp.dat", 'a')
    #fout.write(fstring.format(time(num), *quantum_exp))
    fout.write(fstring.format(num, *quantum_exp))
    fout.close()
  # Ideal
    fout = open("quant_ide.dat", 'a')
    #fout.write(fstring.format(time(num), *quantum_ide))
    fout.write(fstring.format((num), *quantum_ide))
    fout.close()
### Classical
  # Experimental
    fout = open("class_exp.dat", 'a')
    #fout.write(fstring.format(time(num), *classical_exp))
    fout.write(fstring.format((num), *classical_exp))
    fout.close()
  # Ideal
    fout = open("class_ide.dat", 'a')
    #fout.write(fstring.format(time(num), *classical_ide))
    fout.write(fstring.format((num), *classical_ide))
    fout.close()



