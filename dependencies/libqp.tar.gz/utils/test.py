import math
import sys
import numpy as np
from scipy import linalg

def H(A,B,t):
  return (math.pi*t/4.)*A - (math.pi*t**2/36.)*B

if __name__=='__main__':
  if len(sys.argv) > 1:
    theta = float(sys.argv[1])
  else:
    print "enter a value for time\n"
    sys.exit(1)
  A = np.array([[1,-1,-1,-1],[-1,1,1,1],[-1,1,1,1],[-1,1,1,1]], dtype=complex)
  B = np.array([[0,0,0,0],[0,1,0,-1],[0,0,0,0],[0,-1,0,1]], dtype=complex)
  D = np.array([[0 for i in range(4)] for j in range(4)], dtype=complex)

  evals, evecs = linalg.eig(H(theta))
  for i in range(4):
    D[i,i] = np.exp(-complex(0,1)*
