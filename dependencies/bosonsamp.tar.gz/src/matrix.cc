// matrix.cc
// specialised matrix functions

#include "heads/matrix.h"
#include "heads/permanent.h"

matrix<std::complex<double> > haar(uint n, uint seed){
  gsl_rng *r = gsl_rng_alloc(gsl_rng_mt19937);
  matrix<std::complex<double> > m(n);
  std::complex<double> z,ii,ij;
  double x,y;
  gsl_rng_set(r, seed);
  // Generate Gaussian random matrix
  for (uint i=0; i<m.size()*m.size(); i++){ 
    x = gsl_ran_gaussian(r, 0.5);
    y = gsl_ran_gaussian(r, 0.5);
    z = std::complex<double>(x, y);
    m[i] = z;
  }
  gsl_rng_free(r);
  // Apply Gram-Schmidt
  for (uint i=0; i<n; i++){
    // Normalise the i-th row
    ii = 0;
    for (uint k=0; k<n; k++){
      ii += std::conj(m[i*n+k])*m[i*n+k];
    }
    ii = std::sqrt(ii);
    for (uint k=0; k<n; k++){
      m[i*n+k] = m[i*n+k]/ii;
    }
    for (uint j=i+1; j<n; j++){
      // Compute the projection
      ij = 0;
      for (uint k=0; k<n; k++){
        ij += std::conj(m[i*n+k])*m[j*n+k];
      }
      // Subtract the projection
      for (uint k=0; k<n; k++){
        m[j*n+k] = m[j*n+k]-ij*m[i*n+k];
      }
    }
  }
  return m;
}

matrix<std::complex<double> > walk(uint n, double diag,
    std::complex<double> coupling, double time){
  matrix<std::complex<double> > hamiltonian(n, 0);
  
  // Construct the Hamiltonian
  for (uint i=0; i<n-1; i++){
    hamiltonian[i*n+i] = diag;
    hamiltonian[i*n+(i+1)] = coupling;
    hamiltonian[(i+1)*n+i] = std::conj(coupling);
  }
  hamiltonian[n*n-1] = diag;
  return expi(hamiltonian, time);
}

double PowerAtEdges(matrix<std::complex<double> > U, uint nphotons){
  std::complex<double> z;
  double power=0, max;
  uint nmodes=U.size();
  z = U[(nmodes-nphotons)/2];
  max=std::real(z*std::conj(z));
  for (uint i=1; i<nphotons; i++){
    z = U[(nmodes-nphotons)/2+i];
    power=std::real(z*std::conj(z));
    if (power>max){
      max=power;
    }
  }
  return max;
}

matrix<std::complex<double> > WalkToEdges(uint nmodes, uint nphotons,
    std::complex<double> coupling, double tol, double eps, double imax){
  double time=0, interval=eps, tmin, tmax, delta, power;
  matrix<std::complex<double> > U=walk(nmodes, 0, coupling, time);
  // Find crossover by successive doubling
  power=PowerAtEdges(U,nphotons);
  while (power<tol){
    time += interval;
    U = walk(nmodes, 0, coupling, time);
    power=PowerAtEdges(U,nphotons);
    if (interval<imax){
      interval*=2;
    }
  }
  tmax=time;
  tmin=time/2;
  // Refine crossover by interval bisection
  delta = interval/2;
  while (delta>eps){
    time=(tmax+tmin)/2;
    delta=delta/2;
    U = walk(nmodes, 0, coupling, time);
    power=PowerAtEdges(U, nphotons);
    if (power>tol){
      tmax=time;
    }
    else{
      tmin=time;
    }
  }
  time=tmin;
  std::cout << "# " << time << std::endl;
  U = walk(nmodes, 0, coupling, time);
  return U;
}

matrix<std::complex<double> > realWalk(uint nmodes, double time){
  matrix<std::complex<double> > H(nmodes,0);
  double coupling[20]={0.466,0.540,0.504,0.515,0.494,0.451,0.508,0.511,0.483,
    0.505,0.547,0.471,0.493,0.499,0.447,0.467,0.544,0.524,0.510,0.503};
  double diag=2.122;
  
  // Construct the Hamiltonian
  for (uint i=0; i<nmodes-1; i++){
    H[i*nmodes+i]=diag;
    H[i*nmodes+(i+1)]=coupling[i%20];
    H[(i+1)*nmodes+i]=coupling[i%20];
  }
  H[nmodes*nmodes-1] = diag;

  return expi(H, time);
}

matrix<std::complex<double> > expi(matrix<std::complex<double> > H, double t){
  uint size=H.size();
  gsl_matrix_complex* m, *rtn, *evec, *expdiag;
  gsl_vector* eval;
  gsl_vector_complex* cdiag;
  gsl_eigen_hermv_workspace* wspace;
  gsl_vector_complex_view diag;
  matrix<std::complex<double> > U(size);
  gsl_complex zgsl;
  std::complex<double> z;
  double lambda;

  // Construct a GSL matrix from the Hermitian H
  m = gsl_matrix_complex_alloc(size, size);
  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      z = H[i*size+j];
      zgsl = gsl_complex_rect(std::real(z), std::imag(z));
      gsl_matrix_complex_set(m, i, j, zgsl);
    }
  }

  // Do the diagonalisation
  wspace = gsl_eigen_hermv_alloc(size);
  evec = gsl_matrix_complex_alloc(size, size);
  expdiag = gsl_matrix_complex_calloc(size, size);
  rtn = gsl_matrix_complex_calloc(size, size);
  eval = gsl_vector_alloc(size);
  cdiag = gsl_vector_complex_alloc(size);
  gsl_eigen_hermv(m, eval, evec, wspace);

  // Construct the unitary
  gsl_matrix_complex_set_zero(m);
  // Exponentiate the diagonal matrix
  for (uint i=0; i<size; i++){
    lambda = gsl_vector_get(eval, i);
    zgsl = gsl_complex_mul_real(gsl_complex_rect(0,1), t*lambda);
    zgsl = gsl_complex_exp(zgsl);
    gsl_vector_complex_set(cdiag, i, zgsl);
  }
  diag = gsl_matrix_complex_diagonal(expdiag);
  gsl_vector_complex_memcpy(&diag.vector, cdiag);

  // Multiply the matrices to obtain a unitary
  gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, gsl_complex_rect(1,0), evec,
    expdiag, gsl_complex_rect(1,0), rtn);
  gsl_blas_zgemm(CblasNoTrans, CblasConjTrans, gsl_complex_rect(1,0), rtn,
    evec, gsl_complex_rect(1,0), m);

  // Copy the matrices back to the unitary
  for (uint i=0; i<size; i++){
    for (uint j=0; j<size; j++){
      zgsl = gsl_matrix_complex_get(m, i, j);
      U[i*size+j] = std::complex<double>(GSL_REAL(zgsl), GSL_IMAG(zgsl));
    }
  }

  gsl_matrix_complex_free(m);
  gsl_matrix_complex_free(evec);
  gsl_matrix_complex_free(expdiag);
  gsl_matrix_complex_free(rtn);
  gsl_eigen_hermv_free(wspace);
  gsl_vector_complex_free(cdiag);
  gsl_vector_free(eval);

  return U;
}

std::complex<double> amplitude(multiset out, matrix<std::complex<double> > U,
    multiset in){
  uint m,p;
  m = U.size();    // Assume for now equal to in.bins() and out.bins()
  p = out.items(); // Assume for now equal to in.items()
  matrix<std::complex<double> > submat(p);
  for (uint i=0; i<p; i++){
    for (uint j=0; j<p; j++){
      submat[i*p+j] = U[out[i]*m+in[j]];
    }
  }
  return permanent(submat)*norm(out)*norm(in);
}

std::complex<double> amplitude(combination out,
    matrix<std::complex<double> > U, combination in){
  uint m,p;
  m = U.size();    // Assume for now equal to in.bins() and out.bins()
  p = out.items(); // Assume for now equal to in.items()
  matrix<std::complex<double> > submat(p);
  for (uint i=0; i<p; i++){
    for (uint j=0; j<p; j++){
      submat[i*p+j] = U[out[i]*m+in[j]];
    }
  }
  return permanent(submat);
}

double probability_quantum(combination out, matrix<std::complex<double> > U,
    combination in){
  std::complex<double> z;
  z = amplitude(out, U, in);
  return std::real(z*std::conj(z));
}

double probability_classical(combination out,
    matrix<std::complex<double> > U, combination in){
  uint m,p;
  m = U.size();    // Assume for now equal to in.bins() and out.bins()
  p = out.items(); // Assume for now equal to in.items()
  matrix<double> submat(p);
  std::complex<double> z;
  for (uint i=0; i<p; i++){
    for (uint j=0; j<p; j++){
      z = U[out[i]*m+in[j]];
      submat[i*p+j] = std::real(z*std::conj(z));
    }
  }
  return permanent(submat);
}

double probability_quantum(multiset out, matrix<std::complex<double> > U,
    multiset in){
  std::complex<double> z;
  z = amplitude(out, U, in);
  return std::real(z*std::conj(z));
}

double probability_classical(multiset out,
    matrix<std::complex<double> > U, multiset in){
  uint m,p;
  m = U.size();    // Assume for now equal to in.bins() and out.bins()
  p = out.items(); // Assume for now equal to in.items()
  matrix<double> submat(p);
  std::complex<double> z;
  for (uint i=0; i<p; i++){
    for (uint j=0; j<p; j++){
      z = U[out[i]*m+in[j]];
      submat[i*p+j] = std::real(z*std::conj(z));
    }
  }
  return permanent(submat);
}



