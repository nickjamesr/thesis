// matrix.h
// header file for my (minimal) matrix class

#ifndef matrix_h 
#define matrix_h

#include <cstdlib>
#include <iostream>
#include <complex>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_complex.h>
#include <gsl/gsl_complex_math.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_blas.h>

#include "combinatorics.h"

template <class T>
class matrix{
  private:
    uint dim;
    T *data;
  protected:
  public:
    // Constructors
    matrix();
    matrix(uint n);
    matrix(uint n, T t);
    matrix(const matrix<T>&);
    // Destructor
    ~matrix();
    // Overloads
    matrix<T> operator=(const matrix<T>&);
    // Access
    T& operator[](uint);
    uint size();
    // Output
    void print(std::ostream &fout=std::cout) const;
};

template <class T>
matrix<T> PermuteMatrix(matrix<T>, uint*, uint*);

matrix<std::complex<double> > haar(uint, uint seed=0);
matrix<std::complex<double> > walk(uint, double, std::complex<double>, double);
matrix<std::complex<double> > WalkToEdges(uint, uint, std::complex<double>,
    double tol=0.01, double eps=0.01, double imax=50);
matrix<std::complex<double> > realWalk(uint nmodes=21, double time=7);
matrix<std::complex<double> > expi(matrix<std::complex<double> >, double);
std::complex<double> amplitude(multiset, matrix<std::complex<double> >,
  multiset);
std::complex<double> amplitude(combination, matrix<std::complex<double> >,
  combination);
double probability_quantum(combination, matrix<std::complex<double> >,
  combination);
double probability_classical(combination, matrix<std::complex<double> >,
  combination);
double probability_quantum(multiset, matrix<std::complex<double> >,
  multiset);
double probability_classical(multiset, matrix<std::complex<double> >,
  multiset);

#include "matrix.cc"

#endif
